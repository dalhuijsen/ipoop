/*
 * @(#)hprof_method.h	1.1 98/08/14
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#ifndef _HPROF_METHOD_H
#define _HPROF_METHOD_H

void hprof_method_table_init(void);
hprof_method_t * hprof_lookup_method(jmethodID method_id);
hprof_method_t * hprof_intern_method(JVMPI_Method *jmethod, hprof_class_t *hclass);
void hprof_method_entry_event(JNIEnv *env_id, jmethodID method_id);
void hprof_method_exit_event(JNIEnv *env_id, jmethodID method_id);

#endif /* _HPROF_METHOD_H */
