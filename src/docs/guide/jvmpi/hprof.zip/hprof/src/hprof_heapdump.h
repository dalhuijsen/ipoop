/* @(#)hprof_heapdump.h	1.2 98/08/25
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#ifndef _HPROF_HEAPDUMP_H
#define _HPROF_HEAPDUMP_H

void hprof_heap_dump_event(char *begin_roots,
			   char *end_objects,
			   int num_traces,
			   JVMPI_CallTrace *traces);

void hprof_get_heap_dump(void);
void hprof_object_dump_event(char *data);

#endif /* _HPROF_HEAPDUMP_H */
