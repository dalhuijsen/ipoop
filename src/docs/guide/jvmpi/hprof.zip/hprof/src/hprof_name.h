/*
 * @(#)hprof_name.h	1.1 98/08/14
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#ifndef _HPROF_NAME_H
#define _HPROF_NAME_H

/* Names */
typedef struct hprof_name_t {
    int marked;                        /* been written to the output? */
    char *name;                        /* name */
} hprof_name_t;

void hprof_name_table_init(void);
void hprof_output_name(hprof_name_t *name);
hprof_name_t * hprof_intern_name(char *name);

#endif /* _HPROF_NAME_H */
