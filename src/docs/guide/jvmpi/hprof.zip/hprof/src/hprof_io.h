/*
 * @(#)hprof_io.h	1.1 98/08/14
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#ifndef _HPROF_IO_H
#define _HPROF_IO_H

void hprof_write_header(unsigned char type, jint length);
void hprof_write_dev(void *buf, int len);
void hprof_write_raw(void *buf, int len);
void hprof_flush(void);
void hprof_printf(char *fmt, ...);
void hprof_write_current_ticks();
void hprof_write_u4(unsigned int i);
void hprof_write_u2(unsigned short i);
void hprof_write_u1(unsigned char i);
void hprof_write_id(void *p);
void hprof_io_setup(void);

void hprof_dump_seek(char *ptr);
char * hprof_dump_cur(void);
void hprof_dump_read(void *buf, int size);
void * hprof_dump_read_id(void);
unsigned int hprof_dump_read_u4(void);
unsigned short hprof_dump_read_u2(void);
unsigned char hprof_dump_read_u1(void);

#endif /* _HPROF_IO_H */
