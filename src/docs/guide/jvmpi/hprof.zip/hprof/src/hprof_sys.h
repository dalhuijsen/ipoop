/*
 * @(#)hprof_sys.h	1.1 98/08/14
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#ifndef _HPROF_SYS_H
#define _HPROF_SYS_H

/* Defined in platform-specific code */

int hprof_send(int s, const char *msg, int len, int flags);
int hprof_write(int filedes, const void *buf, size_t nbyte);
jint hprof_get_milliticks(void);
jlong hprof_get_timemillis(void);
void hprof_get_prelude_path(char *path);

#endif /* _HPROF_SYS_H */
