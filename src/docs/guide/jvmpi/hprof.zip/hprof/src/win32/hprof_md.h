/*
 * @(#)hprof_md.h	1.1 98/06/09
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#ifndef _WIN32_HPROF_MD_H_
#define _WIN32_HPROF_MD_H_

#include <io.h>
#include <winsock2.h>
#include <stdlib.h>

#define MAXPATHLEN _MAX_PATH

#endif /*_WIN32_HPROF_MD_H_*/
