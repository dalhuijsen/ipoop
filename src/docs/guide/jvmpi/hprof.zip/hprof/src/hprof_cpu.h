/* @(#)hprof_cpu.h	1.1 98/08/14
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#ifndef _HPROF_CPUSAMPLE_H
#define _HPROF_CPUSAMPLE_H

struct hprof_objmap_t;

void hprof_cpu_sample_off(struct hprof_objmap_t *thread_id);
void hprof_cpu_sample_on(struct hprof_objmap_t *thread_id);
void hprof_start_cpu_sampling_thread(void);

#endif /* _HPROF_CPUSAMPLE_H */
